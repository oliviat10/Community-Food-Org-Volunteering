package ort13_CommunityFoodVolunteeringManager;

/**
 *Class: CommunityFoodOrg
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class CommunityFoodOrg {
	//Declaration of attributes
	private int weeklyVolunteersNeeded;
	private int weeklyVolunteerSignups;
	public String firstDayOpen;
	public String lastDayOpen;
	private TimeFrame timeOpen;
	public Location location;
	private String id;
	private String name;
	public boolean offersTransportation;

	//Constructor definitions
	public CommunityFoodOrg(String id, String cfoName, Location loc, String firstDO, String lastDO,TimeFrame time, int weekVN, int weekVS, boolean offersT) {
		this.id=id;
		name=cfoName;
		location=loc;
		firstDayOpen=firstDO;
		lastDayOpen=lastDO;
		weeklyVolunteersNeeded=weekVN;
		weeklyVolunteerSignups=weekVS;
		timeOpen=time;
		offersTransportation=offersT;
	}

	//Setter for organization's ID
	public void setID(String id) {
		this.id=id;
	}
	//Getter for organization's ID
	public String getID() {
		return id;
	}
	//Setter for organization's name
	public void stName(String cfoName) {
		name=cfoName;
	}
	//Getter for organization's name
	public String getName() {
		return name;
	}
	//Setter for organization's location
	public void setLocation(Location loc) {
		location=loc;
	}
	//Setter for number of weekly volunteers needed
	public void setWeeklyVolunteersNeeded(int weekVN) {
		weeklyVolunteersNeeded=weekVN;
	}
	//Getter for number of weekly volunteers needed
	public int getWeeklyVolunteersNeeded() {
		return weeklyVolunteersNeeded;
	}
	//Setter for number of weekly volunteer signups
	public void setWeeklyVolunteersSignups(int weekVS) {
		//Ensure number of sign ups does not exceed requirement or equal less than 0
		if (weekVS>weeklyVolunteersNeeded) {
			weeklyVolunteerSignups=weeklyVolunteersNeeded;
		}if (weekVS<0) {
			weeklyVolunteerSignups=0;
		}
		weeklyVolunteerSignups=weekVS;
	}
	//Getter for number of weekly volunteer signups
	public int getWeeklyVolunteerSignups() {
		return weeklyVolunteerSignups;
	}
	//Setter for first day of the week that organization is open
	public void setFirstDayOpen(String firstDO) {
		firstDayOpen=firstDO;
	}
	//Getter for first day of the week that organization is open
	public String getFirstDayOpen() {
		return firstDayOpen;
	}
	//Setter for last day of the week that organization is open
	public void setLastDayOpen(String lastDO) {
		lastDayOpen=lastDO;
	}
	//Getter for last day of the week that organization is open
	public String getLastDayOpen() {
		return lastDayOpen;
	}
	//Setter for whether or not organization offers transportation to its volunteers
	public void setOffersTransportation(boolean offersT) {
		offersTransportation=offersT;
	}
	//Getter for whether or not organization offers transportation to its volunteers
	public boolean getOffersTransportation() {
		return offersTransportation;
	}
	//Setter for the duration of time that the organization is open daily
	public void setTimeOpen(TimeFrame time) {
		timeOpen=time;
	}
	//Getter for the duration of time that the organization is open daily
	public TimeFrame getTimeOpen() {
		return timeOpen;
	}
	//Method for returning the number of remaining volunteer spots
	public int weeklyVolunteerSpotsLeft() {
		return (weeklyVolunteersNeeded-weeklyVolunteerSignups);
	}
	//Method for signing up a volunteer to the organization
	public boolean signUpVolunteer() {
		//Ensure availability and that number of sign ups does not exceed volunteer requirement
		if (weeklyVolunteerSpotsLeft()>0){
			weeklyVolunteerSignups++;
			if (weeklyVolunteerSignups>weeklyVolunteersNeeded) {
				weeklyVolunteerSignups=weeklyVolunteersNeeded;
			}
			return true;
		}else {
			return false;
		}
	}
	//Method for canceling a volunteer sign up
	public void cancelVolunteerSignup() { 
		//Ensure there is a volunteer already signed up who can be removed
		if (weeklyVolunteerSignups>0) {
			weeklyVolunteerSignups--;
		}else {
			System.out.println("No volunteer has signed up yet");
		}
	}

	//Integer variables to hold indices of week days
	public int firstDayOpenIndex;
	public int lastDayOpenIndex;
	//Method to determine corresponding index value given a day of the week
	public int getDayIndex (String dayAv){
		String[] days= {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
		//Iterate through days of the week
		for (int i=0; i<days.length;i++) {
			//Set the index value of the organization's first week day open
			if (days[i].equals(firstDayOpen)) {
				firstDayOpenIndex=i;
			}//Set the index value of the organization's last week day open
			if (days[i].equals(lastDayOpen)) {
				lastDayOpenIndex=i;
			}//Return the index value of the day volunteer is available
			if (days[i].equals(dayAv)) {
				return i;
			}
		}return 0; 

	}
}


