package ort13_CommunityFoodVolunteeringManager;

/**
 *Class: CommunityFoodVolunteeringTester
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class CommunityFoodVolunteeringTester {
	//Main method for creation of objects and testing
	public static void main(String[] args) {
		//Four new time frames (objects of the TimeFrame class, utilizing different constructors)
		TimeFrame tf1 = new TimeFrame(10,0,13,45);
		TimeFrame tf2 = new TimeFrame(10,17);
		TimeFrame tf3 = new TimeFrame(11,30,12,45);
		TimeFrame tf4 = new TimeFrame(9,0,19,0);

		//Four new organization locations (objects of the Location class) [info from https://www.foodpantries.org/ci/pa-pittsburgh]  
		Location loc1 = new Location(40.495110,-80.011932,"845 Perry Hwy Route 19","Pittsburgh","PA","15229");
		Location loc2 = new Location(40.419182,-79.975471,"2201 Salisbury Street","Pittsburgh","PA","15210");
		Location loc3 = new Location(40.427890,-79.977420,"2005 Sarah Street","Pittsburgh","PA","15203");
		Location loc4 = new Location(40.419392,-79.928459,"828 Hazelwood Ave","Pittsburgh","PA","15217" );

		//Two new volunteers (objects of the Volunteer class)
		Volunteer vol1 = new Volunteer("MJ", "Mary Jane", 18, loc3,"Wednesday",tf3,65,true);
		Volunteer vol2 = new Volunteer("JB", "Jack Black",52, loc2,"Monday",tf2,20,false);

		//Two new organizations (objects of the CommunityFoodOrg class)
		CommunityFoodOrg cfo1 = new CommunityFoodOrg("SHFP", "Squirrel Hill Food Pantry", loc4,"Monday","Friday",tf4, 25,20,false);
		CommunityFoodOrg cfo2 = new CommunityFoodOrg("NHFP", "North Hills Food Bank", loc1, "Tuesday", "Thursday",tf1, 18, 15,true);

		//Check if each volunteer is able to partner with each organization
		String check;
		vol1.orgMatch(cfo1);
		if(vol1.orgMatch(cfo1)) {
			//Volunteer is a match for the organization
			check="can";
		}else {//Volunteer is not a match for the organization (one or more conflicting variables)
			check="cannot";
		}//Print compatibility statement
		System.out.println(vol1.getFullName() + " " + check + " volunteer on " + cfo1.getName() + " on " + vol1.getDayAvailable());

		vol1.orgMatch(cfo2);
		if(vol1.orgMatch(cfo2)) {
			check="can";
		}else {
			check="cannot";
		}System.out.println(vol1.getFullName() + " " + check + " volunteer on " + cfo2.getName() + " on " + vol1.getDayAvailable());

		vol2.orgMatch(cfo1);
		if(vol2.orgMatch(cfo1)) {
			check="can";
		}else {
			check="cannot";
		}System.out.println(vol2.getFullName() + " " + check + " volunteer on " + cfo1.getName() + " on " + vol2.getDayAvailable());

		vol2.orgMatch(cfo2);
		if(vol2.orgMatch(cfo2)) {
			check="can";
		}else {
			check="cannot";
		}System.out.println(vol2.getFullName() + " " + check + " volunteer on " + cfo2.getName() + " on " + vol2.getDayAvailable());

		//Pre-check on volunteer sign up count (before signUp() method)
		//System.out.println(cfo2.getWeeklyVolunteerSignups());

		//Sign up Mary Jane to North Hills Food Bank on Wednesday
		vol1.signUp(cfo2);

		//Post-check on volunteer sign up count (result of signUp() method)
		//System.out.println(cfo2.getWeeklyVolunteerSignups());

		//Sign up Jack Black to Squirrel Hill Food Pantry on Monday
		vol2.signUp(cfo1);

		//Pre-check on number of volunteer spots left (before cancelSignUp() method)
		//System.out.println(cfo1.weeklyVolunteerSpotsLeft());

		//Cancel Jack Black's volunteer sign up
		vol2.cancelSignup();

		//Post-check on number of volunteer spots left (after cancelSignUp() method)
		//System.out.println(cfo1.weeklyVolunteerSpotsLeft());

	}
}