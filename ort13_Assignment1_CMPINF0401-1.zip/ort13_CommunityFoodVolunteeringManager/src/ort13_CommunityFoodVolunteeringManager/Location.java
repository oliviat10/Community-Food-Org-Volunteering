package ort13_CommunityFoodVolunteeringManager;

/**
 *Class: Location
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class Location {
	//Declaration of attributes
	final double EARTH_RADIUS=3958.8;
	private double latitude;
	private double longitude;
	private String address;
	private String city;
	private String state;
	private String zipCode;

	//Constructor declaration
	public Location(double lat, double lon, String addr, String city, String state, String zip){
		latitude=lat;
		longitude= lon;
		address=addr;
		this.city=city;
		this.state=state;
		zipCode=zip;
	}

	//Setter for latitude
	public void setLatitude(double lat){
		//Ensure latitude value is inside appropriate bounds (if not, set to default)
		if (lat<-90 || lat>90) {
			lat=0;
		}
		latitude=lat;
	}
	//Setter for longitude
	public void setLongitude(double lon){
		//Ensure longitude is inside appropriate bounds (if not, set to default)
		if (lon<-180 || lon>180) {
			lon=0;
		}
		longitude=lon;
	}
	//Setter for address
	public void setAddress(String addr){
		address=addr;
	}
	//Setter for city
	public void setCity(String city){
		this.city=city;
	}
	//Setter for state
	public void setState(String state){
		this.state=state;
	}
	//Setter for zip code
	public void setZipCode(String zip){
		zipCode=zip;
	}
	//Getter for latitude
	public double getLatitude(){
		return latitude;
	}
	//Getter for longitude
	public double getLongitude(){
		return longitude;
	}
	//Getter for address
	public String getAddress(){
		return address;
	}
	//Getter for city
	public String getCity(){
		return city;
	}
	//Getter for state
	public String getState(){
		return state;
	}
	//Getter for zip code
	public String getZipCode(){
		return zipCode;
	}

	//Method for distance calculation
	public double distance(Location loc) {
		//Coordinates of first location
		double lat1= latitude;
		double lon1= longitude;
		//Coordinates of second location
		double lat2= loc.getLatitude();
		double lon2=loc.getLongitude();
		//Convert the difference in the latitudes of the two locations to radians
		double changeInLat= Math.toRadians(lat2-lat1);
		//Convert the difference in the longitudes of the two locations to radians
		double changeInLon= Math.toRadians(lon2-lon1);
		//Harvesine distance calculations
		double a= Math.pow((Math.sin(changeInLat/2)),2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(changeInLon/2), 2);
		double c= 2* Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
		double distanceBetween= EARTH_RADIUS*c;
		//Return distance in miles between the two locations
		return distanceBetween;
	}
}

