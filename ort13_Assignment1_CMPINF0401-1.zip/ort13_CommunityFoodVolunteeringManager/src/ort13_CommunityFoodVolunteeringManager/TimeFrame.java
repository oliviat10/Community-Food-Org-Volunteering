package ort13_CommunityFoodVolunteeringManager;

/**
 *Class: TimeFrame
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class TimeFrame {
	//Attribute declarations
	public int hourStart;
	public int minuteStart;
	public int hourEnd;
	public int minuteEnd;

	//First constructor (hour values only)
	public TimeFrame(int hourStart, int hourEnd){
		this.hourStart=hourStart;
		this.hourEnd=hourEnd;
		minuteStart=0;
		minuteEnd=0;
	}

	//Second constructor (minute-inclusive)
	public TimeFrame(int hourStart, int minuteStart, int hourEnd, int minuteEnd) {
		this.hourStart=hourStart;
		this.minuteStart=minuteStart;
		this.hourEnd=hourEnd;
		this.minuteEnd=minuteEnd;
	}

	//Setter for starting hour of the time frame
	public void setHourStart(int hourStart) {
		//Ensure the starting hour is a feasible value (if not, default to 8)
		if (hourStart<0 || hourStart>23) {
			hourStart=8;
		}
		this.hourStart=hourStart;
	}
	//Getter for starting hour
	public int getHourStart() {
		return hourStart;
	}

	//Setter for ending hour of the time frame
	public void setHourEnd(int hourEnd) {
		//Ensure the ending hour is a feasible value (if not, default to 8)
		if (hourEnd<0 || hourEnd>23) {
			hourEnd=8;
		}
		this.hourEnd=hourEnd;
	}
	//Getter for ending hour
	public int getHourEnd() {
		return hourEnd;
	}

	//Setter for starting minutes of time frame
	public void setMinuteStart(int minuteStart) {
		//Ensure the starting minute value is feasible (if not, default to 0)
		if (minuteStart<0 || minuteStart>59) {
			minuteStart=0;
		}
		this.minuteStart=minuteStart;
	}
	//Getter for starting minutes
	public int getMinuteStart() {
		return minuteStart;
	}

	//Setter for ending minutes of time frame
	public void setMinuteEnd(int minuteEnd) {
		//Ensure the ending minute value is feasible (if not, default to 0)
		if (minuteEnd<0 || minuteEnd>59) {
			minuteEnd=0;
		}
		this.minuteEnd=minuteEnd;
	}
	//Getter for ending minutes
	public int getMinuteEnd() {
		return minuteEnd;
	}

	//Method for determining if a volunteer is available during the organization's open hours
	public boolean timeFrameMatch(TimeFrame time){
		if (hourStart>=time.hourStart){
			if (minuteStart>=time.minuteStart) {
				if (hourEnd<=time.hourEnd) {
					if (minuteEnd<=time.minuteEnd){
						return true;
					}
				}
			}
		}
		return false;
	}
}