package ort13_CommunityFoodVolunteeringManager;

/**
 *Class: Volunteer
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class Volunteer {
	//Attribute declaration
	private String id;
	private String fullName;
	private int age;
	private Location location;
	private String dayAvailable;
	private TimeFrame timeAvailable;
	private double distanceAvailable;
	private boolean needsTransportation;
	private CommunityFoodOrg orgVolunteering;

	//Constructor definition
	public Volunteer(String id, String name, int age, Location loc, String dayAv, TimeFrame timeAv, double distAv, boolean needTrans) {
		this.id=id;
		fullName=name;
		this.age=age;
		location=loc;
		dayAvailable=dayAv;
		timeAvailable=timeAv;
		distanceAvailable=distAv;
		needsTransportation=needTrans;
	}

	//Setter for volunteer ID
	public void setID(String id) {
		this.id=id;
	}
	//Getter for volunteer ID
	public String getID() {
		return id;
	}
	//Setter for volunteer's full name
	public void setFullName(String name) {
		fullName=name;
	}
	//Getter for volunteer's full name
	public String getFullName() {
		return fullName;
	}
	//Setter for volunteer's age
	public void setAge(int age) {
		//Ensure volunteer is within the age requirement (if not, assume/default to 18)
		if (age<18 || age>100) {
			age=18;
		}
		this.age=age;
	}
	//Getter for volunteer's age
	public int getAge() {
		return age;
	}
	//Setter for volunteer organization
	public void setOrganization(CommunityFoodOrg org) {
		orgVolunteering=org;
	}
	//Getter for volunteer organiztion
	public CommunityFoodOrg getOrganization() {
		return orgVolunteering;
	}
	//Setter for volunteer's day of availability
	public void setDayAvailable(String dayAv) {
		//Ensure available day of the week is valid
		if(dayAv.equals("Monday") || dayAv.equals("Tuesday") || dayAv.equals("Wednesday") || dayAv.equals("Thursday") || dayAv.equals("Friday") || dayAv.equals("Saturday") || dayAv.equals("Sunday")) {
			dayAvailable=dayAv;
		}else {//If not, default to Monday
			dayAvailable="Monday";
		}
	}
	//Getter for volunteer's day of availability
	public String getDayAvailable() {
		return dayAvailable;
	}
	//Setter for volunteer's available time frame
	public void setTimeAvailability(TimeFrame timeAv) {
		//Ensure validity of hour and minute start and end times
		if (timeAv.hourStart<0 || timeAv.hourStart>23){
			timeAvailable.hourStart=8;
		}if (timeAv.hourEnd<0 || timeAv.hourEnd>23) {
			timeAvailable.hourEnd=8;
		}if (timeAv.minuteStart<0 || timeAv.minuteStart>59) {
			timeAvailable.minuteStart=0;
		}if (timeAv.minuteEnd<0 || timeAv.minuteEnd>59) {
			timeAvailable.minuteEnd=0;
		}else {
			timeAvailable=timeAv;
		}
	}
	//Getter for volunteer's available time frame
	public TimeFrame getTimeAvailability() {
		return timeAvailable;
	}
	//Setter for volunteer's available distance
	public void setDistanceAvailable(double distanceAv) {
		distanceAvailable=distanceAv;
	}
	//Getter for volunteer's available distance
	public double getDistanceAvailable() {
		return distanceAvailable;
	}
	//Setter for whether or not volunteer needs transportation
	public void setNeedsTransportation(boolean needTrans) {
		needsTransportation=needTrans;
	}
	//Getter for whether or not volunteer needs transportation
	public boolean getNeedsTransportation() {
		return needsTransportation;
	}
	//Method for volunteer sign up
	public void signUp(CommunityFoodOrg org) {
		//Adds a volunteer to the organization's sign up count
		if (org.signUpVolunteer()) {
			orgVolunteering=org;
		}
	}
	//Method for canceling a volunteer's sign up
	public void cancelSignup() {
		//Removes a volunteer from the organization's sign up count
		orgVolunteering.cancelVolunteerSignup();
		orgVolunteering=null;
	}
	//Method for determining a volunteer's compatibility with an organization on a given day/time
	public boolean orgMatch(CommunityFoodOrg org) {
		//Determines whether the index of volunteer's available day is greater than that of the organization's first day open
		boolean checkFirstDay= (org.getDayIndex(dayAvailable)) >= (org.getDayIndex(org.getFirstDayOpen()));
		//Determines whether the index of volunteer's available day is less than that of the organization's last day open
		boolean checkLastDay= (org.getDayIndex(dayAvailable)) <= (org.getDayIndex(org.getLastDayOpen()));
		//Compatible if a volunteer needs transportation and an organization offers it
		//Or if volunteer doesn't need transportation
		if ((needsTransportation && org.offersTransportation) || needsTransportation==false) {
			//Compatible if both index checks on day of availability are true
			if (checkFirstDay && checkLastDay) {
				//Compatible if volunteer's available time frame fits within the organization's open hours
				if (timeAvailable.timeFrameMatch(org.getTimeOpen())) {
					//Compatible if the distance between the volunteer and the organization is less than or equal to the volunteer's available distance
					if (this.location.distance(org.location)<=distanceAvailable) {
						//Volunteer is completely eligible to volunteer with organization on given day/time
						return true;
					}
				}
			}//Volunteer is ineligible to volunteer with organization on given day/time
		}return false;
	}
}





