module ort13_FinalProject_CMPINF0401 {
	requires java.desktop;
}