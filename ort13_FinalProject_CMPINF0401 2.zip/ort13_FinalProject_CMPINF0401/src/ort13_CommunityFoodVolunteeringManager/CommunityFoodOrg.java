package ort13_CommunityFoodVolunteeringManager;

/**
 * Class CommunityFoodOrg
 * author: Olivia Terry
 * created: 05/01/2022
 */


public class CommunityFoodOrg {
	private String id;
	private String name;
	private Location location;
	private TimeFrame[] dailyOpenHours;
	private boolean offersTransportation;
	
	
	//Constructor
	public CommunityFoodOrg(String id, String name, Location loc, TimeFrame[] dailyOH, boolean offersT) {
		this.id = id;
		this.name = name;
		this.location = loc;
		
		//Setters take care of the validity of each of the arguments
		setDailyOpenHours(dailyOH);
		
		this.offersTransportation = offersT;
		
	}
	
	//Define setters and getters
	
	//Getters
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public Location getLocation() {
		return location;
	}
	
	public boolean getOffersTransportation() {
		return offersTransportation;
	}
	
	public TimeFrame[] getDailyOpenHours() {
		return dailyOpenHours;
	}
	
	//Setters
	public void setId(String newId) {
		id = newId;
	}
	public void setName(String newName) {
		name = newName;
	}
	public void setLocation(Location newLocation) {
		location = newLocation;
	}
	
	public void setDailyOpenHours(TimeFrame[] dailyOpenHours) {
		TimeFrame[] defaultArray = {null,null,null,null,null,null,null};
		boolean validArray = true;
		if(dailyOpenHours.length>7) {
			validArray = false;
			this.dailyOpenHours = defaultArray;
		}
		if(validArray) {
			this.dailyOpenHours = dailyOpenHours;
		}
	}
	
	public void setDailyHours(TimeFrame timeframe, String dayName){
		//Change how many volunteers are needed for that specific day
		int index = mapDayToIndex(dayName);
		dailyOpenHours[index] = timeframe;

	}
	

	public void setOffersTransportation(boolean newOffersTransportation) {
		offersTransportation = newOffersTransportation;
	}
	
	
	//Sign up volunteer method to display message
	public boolean signUpVolunteer(Volunteer vol) {
		System.out.println("Checking the necessary information \n"
				+ "for signing up " + vol.getFullName() + " for helping " + String.valueOf(getName()) + " on "
						+ vol.getDayAvailable());
		return true;
	}
	
	//Cancel volunteer signup method to display message
	public void cancelVolunteerSignUp(String dayName) {
		System.out.println("Canceling volunteer signup for " + String.valueOf(getName()) + " on " + dayName);
	}
	

	
	//Method that maps the string name to an index
	public int mapDayToIndex(String day) {
		int index = 0;
		if(day.equals("Monday")) {
			index=0;
		}else if(day.equals("Tuesday")){
			index=1;
		}else if(day.equals("Wednesday")) {
			index=2;
		}else if(day.equals("Thursday")) {
			index=3;
		}else if(day.equals("Friday")) {
			index=4;
		}else if(day.equals("Saturday")) {
			index=5;
		}else {
			index=6;
		}
		return index;
	}
	
	public static void main(String[] args){

	}
}

