package ort13_CommunityFoodVolunteeringManager;

/**
 * Class CommunityFoodOrgVolunteeringGUI
 * author: Olivia Terry
 * created: 05/01/2022
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

public class CommunityFoodOrgVolunteeringGUI {
	//Define the attributes of the GUI class here
	public ArrayList<Volunteer> volunteersList;
	//Create a new VolunteeringManager object to read from text files
	public VolunteeringManager volManager = new VolunteeringManager("community_food_organizations.txt","volunteers.txt");
	
	//Attributes related to the graphical elements
	public JFrame frmMainWindow;
	public JLabel lblFullName;
	public JTextField txtFullName;
	public JLabel lblAge;
	public JTextField txtAge;
	public JLabel lblDistAvailability;
	public JLabel lblMiles;
	public JLabel lblNeedsTransportation;
	public JCheckBox chkNeedsTransportation;
	public JLabel lblDayAvailable;
	public JComboBox<String> cboDayAvailable;
	public JTextField txtHourAvFrom;
	public JTextField txtMinAvFrom;
	public JTextField txtHourAvTo;
	public JTextField txtMinAvTo;
	public JTextField txtDistAvailability;
	public JLabel lblFrom;
	public JLabel lblTo;
	public JButton btnAddVolunteer;
	public JLabel lblLatitude;
	public JTextField txtLatitude;
	public JLabel lblLongitude;
	public JTextField txtLongitude;
	public JLabel lblAddressStreetAddress;
	public JTextField txtAddressStreetAddress;
	public JLabel lblAddressCity;
	public JTextField txtAddressCity;
	public JLabel lblAddressState;
	public JTextField txtAddressState;
	public JLabel lblAddressZip;
	public JTextField txtAddressZip;
	public JLabel lblDonation;
	public JTextField txtDonation;
	public JLabel lblFoodOrgs;
	public JList<String> lstFoodOrgs;
	public JButton btnSignUpVolunteer;
	
	
	
	public CommunityFoodOrgVolunteeringGUI() {
		//Creates main JFrame
		frmMainWindow = new JFrame("CommunityFoodOrgVolunteeringGUI");
		frmMainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmMainWindow.setResizable(false);
        frmMainWindow.setBounds(200,200,670,580);
        frmMainWindow.setLayout(null);
        
		
		//Create all the graphical elements (labels, textfields, combobox for days, checkbox for need transportation, addVolunteer button) 
		//dont forget to set the bounds of each of them
		lblFullName = new JLabel("Full name");
		lblFullName.setBounds(20,20,100,20);
		
		txtFullName = new JTextField("Please type your name ...");
		txtFullName.setBounds(90,20,200,20);
		
		lblAge = new JLabel("Age");
		lblAge.setBounds(20,50,100,20);
		
		txtAge = new JTextField("Please type your age ...");
		txtAge.setBounds(90,50,200,20);
		
		btnAddVolunteer = new JButton("Add volunteer");
		btnAddVolunteer.setBounds(265,515,150,30); 
		
		lblDistAvailability = new JLabel("Available up to ");
		lblDistAvailability.setBounds(20,80,100,40);
		lblMiles = new JLabel(" miles");
		lblMiles.setBounds(200,80,40,40);
		
		txtDistAvailability = new JTextField("");
		txtDistAvailability.setBounds(135,85,50,30);
		
		lblNeedsTransportation = new JLabel("Needs transportation?");
		lblNeedsTransportation.setBounds(20,120,150,30);
		
		chkNeedsTransportation = new JCheckBox();
		chkNeedsTransportation.setBounds(180,110,50,50);
		
		lblDayAvailable = new JLabel("Available on");
		lblDayAvailable.setBounds(20,140,100,40);
		String[] daysOfWeek = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
		cboDayAvailable = new JComboBox<String>(daysOfWeek);
		cboDayAvailable.setBounds(180,140,100,50);
		
		txtHourAvFrom = new JTextField("");
		txtHourAvFrom.setBounds(60,180,40,30);
		txtMinAvFrom = new JTextField("");
		txtMinAvFrom.setBounds(100,180,40,30);
		txtHourAvTo = new JTextField("");
		txtHourAvTo.setBounds(150,180,40,30);
		txtMinAvTo = new JTextField("");
		txtMinAvTo.setBounds(190,180,40,30);
		
		lblFrom = new JLabel("from ");
		lblFrom.setBounds(20,180,40,30);
		lblTo = new JLabel(" to ");
		lblTo.setBounds(135,180,40,30);
		
		lblLatitude = new JLabel("Latitude "); 
		lblLatitude.setBounds(315,20,80,20);
		txtLatitude = new JTextField("");
		txtLatitude.setBounds(390,20,200,20);
		
		lblLongitude = new JLabel("Longitude ");
		lblLongitude.setBounds(315,50,80,20);
		txtLongitude = new JTextField("");
		txtLongitude.setBounds(390,50,200,20);
		
		lblAddressStreetAddress = new JLabel("Street Address ");
		lblAddressStreetAddress.setBounds(315,80,120,15);
		txtAddressStreetAddress = new JTextField("");
		txtAddressStreetAddress.setBounds(425,80,220,20);
		
		lblAddressCity = new JLabel("City ");
		lblAddressCity.setBounds(315,110,60,15);
		txtAddressCity = new JTextField("");
		txtAddressCity.setBounds(355,110,120,20);
		
		lblAddressZip = new JLabel("Zipcode ");
		lblAddressZip.setBounds(315,140,60,15);
		txtAddressZip = new JTextField("");
		txtAddressZip.setBounds(370,140,80,20);
		
		lblAddressState = new JLabel("State" );
		lblAddressState.setBounds(490,110,60,15);
		txtAddressState = new JTextField("");
		txtAddressState.setBounds(525,110,70,20);
		
		lblDonation = new JLabel("Donation Amount (lbs) ");
		lblDonation.setBounds(315,200,170,15);
		txtDonation = new JTextField("");
		txtDonation.setBounds(465,200,100,20);
		
		lblFoodOrgs = new JLabel("Community Food Organizations: ");
		lblFoodOrgs.setBounds(20,240,280,15);
		
		ArrayList<CommunityFoodOrg> orgs=volManager.getOrgs();
		
		String organization;
		DefaultListModel<String> DLM= new DefaultListModel<>();
		lstFoodOrgs= new JList<String>(DLM);
		lstFoodOrgs.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		lstFoodOrgs.setLayoutOrientation(JList.VERTICAL_WRAP);
		lstFoodOrgs.setBounds(20,270,625,200);
		for(int i=0;i<orgs.size();i++) {
			organization=(orgs.get(i).getName());
			DLM.addElement(organization);
		}
		lstFoodOrgs.setModel(DLM);
		
		
		btnSignUpVolunteer= new JButton("Sign Up Volunteer");
		btnSignUpVolunteer.setBounds(465,515,150,30);
		
		
		//Create the list of volunteers
		volunteersList = new ArrayList<Volunteer>();
		
		//Every time the btnAddVolunteer is clicked
		btnAddVolunteer.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent e) {        		
        		//If all the info is valid, create a volunteer object and add it to the volunteersList
    			//if some info  is not valid or fields are empty, show an error message by using the following method

    			try {
    				boolean validInput = true;
    				
    				String fullName = txtFullName.getText();
        			int age = Integer.parseInt(txtAge.getText());
        			String dayAvailable = cboDayAvailable.getSelectedItem().toString();
        			boolean needsTransp = chkNeedsTransportation.isSelected();
        			int hrFrom = Integer.parseInt(txtHourAvFrom.getText());
        			int hrTo = Integer.parseInt(txtHourAvTo.getText());
        			int minFrom = Integer.parseInt(txtMinAvFrom.getText());
        			int minTo = Integer.parseInt(txtMinAvTo.getText());
        			double distAvailable = Double.parseDouble(txtDistAvailability.getText());
        			String currentIndex = ""+volunteersList.size();
        			double donation=Double.valueOf(txtDonation.getText());
        			
        			if((hrFrom>23 || hrFrom<0) || (hrTo>23 || hrTo<0) || (minFrom<0 || minFrom>59) || (minTo<0 || minTo>59) || (distAvailable<0)) {
        				validInput = false;
        			}
        			
        			if(!validInput) {
        				JOptionPane.showMessageDialog(null, "Invalid input!", "Error", JOptionPane.ERROR_MESSAGE);
        			}else {
        				Location location=new Location(0,0,"","","","");
        				TimeFrame timeFrame = new TimeFrame(hrFrom,minFrom,hrTo,minTo);
        				Volunteer vol= new Volunteer(currentIndex,fullName,age,location,dayAvailable,timeFrame,distAvailable,needsTransp,donation);
        				for(int i=0;i<orgs.size();i++) {
        					if(vol.orgMatch(orgs.get(i))) {
        						System.out.println(vol.getFullName() + " is a match for " + volManager.getOrgs().get(i).getName());
        					}
        				}
        				volunteersList.add(vol);  
        			}	
    			}catch(NumberFormatException exc) {
    				JOptionPane.showMessageDialog(null, "Invalid input!", "Error", JOptionPane.ERROR_MESSAGE);
    			}
		
            }
        });
		
		
		//Add the graphical elements to the frame
		frmMainWindow.add(lblFullName);
		frmMainWindow.add(txtFullName);
		frmMainWindow.add(lblAge);
		frmMainWindow.add(txtAge);
		frmMainWindow.add(lblDistAvailability);
		frmMainWindow.add(lblMiles);
		frmMainWindow.add(txtDistAvailability);
		frmMainWindow.add(lblNeedsTransportation);
		frmMainWindow.add(chkNeedsTransportation);
		frmMainWindow.add(lblDayAvailable);
		frmMainWindow.add(cboDayAvailable);
		frmMainWindow.add(txtHourAvFrom);
		frmMainWindow.add(txtMinAvFrom);
		frmMainWindow.add(txtHourAvTo);
		frmMainWindow.add(txtMinAvTo);
		frmMainWindow.add(btnAddVolunteer);
		frmMainWindow.add(lblFrom);
		frmMainWindow.add(lblTo);
		frmMainWindow.add(lblLatitude);
		frmMainWindow.add(txtLatitude);
		frmMainWindow.add(lblLongitude);
		frmMainWindow.add(txtLongitude);
		frmMainWindow.add(lblAddressStreetAddress);
		frmMainWindow.add(txtAddressStreetAddress);
		frmMainWindow.add(lblAddressCity);
		frmMainWindow.add(txtAddressCity);
		frmMainWindow.add(lblAddressZip);
		frmMainWindow.add(txtAddressZip);
		frmMainWindow.add(lblDonation);
		frmMainWindow.add(txtDonation);
		frmMainWindow.add(lstFoodOrgs);
		frmMainWindow.add(lblFoodOrgs);
		frmMainWindow.add(lblAddressState);
		frmMainWindow.add(txtAddressState);
		frmMainWindow.add(btnSignUpVolunteer);
		
		
		
		//Make the frame visible
		frmMainWindow.setVisible(true);
			
			
	}
	public static void main(String[] args) {
		//This line initializes/display all the GUI
		CommunityFoodOrgVolunteeringGUI show = new CommunityFoodOrgVolunteeringGUI();

	}

}
