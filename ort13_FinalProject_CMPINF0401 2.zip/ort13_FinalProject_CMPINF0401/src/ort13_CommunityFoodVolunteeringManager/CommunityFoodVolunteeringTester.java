package ort13_CommunityFoodVolunteeringManager;

import java.util.ArrayList;

/**
 * Class CommunityFoodVolunteeringManagerTest
 * author: Olivia Terry
 * created: 05/01/2022
 */

public class CommunityFoodVolunteeringTester{
	
	//Method that maps the day index to the string name
	static public String mapIndexToDay(int index) {
			String day = "";
			if(index==0) {
				day="Monday";
			}else if(index==1){
				day="Tuesday";
			}else if(index==2) {
				day="Wednesday";
			}else if(index==3) {
				day="Thursday";
			}else if(index==4) {
				day="Friday";
			}else if(index==5) {
				day="Saturday";
			}else {
				day="Sunday";
			}
			return day;
		}

	public static void main(String[] args) {
		
		VolunteeringManager volManager = new VolunteeringManager("./data/community_food_organizations.txt","./data/volunteers.txt");
		ArrayList<Volunteer> volunteers = volManager.getVolunteers();
		ArrayList<CommunityFoodOrg> orgs = volManager.getOrgs();
		
		//Check how many spots left per day per organization, per day, before the signups plus the individual cancellation
		for(int j=0;j<orgs.size();j++) {
			CommunityFoodOrg org = orgs.get(j);
			System.out.println(org.getName());
			for(int k=0;k<7;k++) {
				if( ((FoodPantry)org).dailyVolunteerSpotsLeft(mapIndexToDay(k))>0) {
					System.out.println(mapIndexToDay(k)+" - Volunteer spots left: "+((FoodPantry)org).dailyVolunteerSpotsLeft(mapIndexToDay(k)));
			}
		}
		
		//Assign each of the volunteers read from the volunteers.txt file to the most-priority organization at the moment
		for(int i=0;i<volunteers.size();i++) {
			volManager.signUpVolunteerToPriorityOrg(volunteers.get(i));
			if(volunteers.get(i).getOrgVolunteering()!=null) {
				System.out.println(volunteers.get(i).getFullName()+" signed up for helping "+volunteers.get(i).getOrgVolunteering().getName()+" on "+volunteers.get(i).getDayAvailable());
			}else {
				System.out.println(volunteers.get(i).getFullName()+" could not sign up");
			}
		}
		
		
		//Check how many spots left per day per organization, per day, after the signups plus the individual cancellation
		for(int f=0;f<orgs.size();f++) {
			CommunityFoodOrg org2 = orgs.get(f);
			System.out.println(org2.getName());
			for(int k=0;k<7;k++) {
				if(((FoodPantry)org2).dailyVolunteerSpotsLeft(mapIndexToDay(k))>0)
				System.out.println(mapIndexToDay(k)+" - Volunteer spots left: "+((FoodPantry)org2).dailyVolunteerSpotsLeft(mapIndexToDay(k)));
			}
		}
		
		//We cancel the signup from the first volunteer
		volunteers.get(0).cancelSignup();
		}
	}

}
