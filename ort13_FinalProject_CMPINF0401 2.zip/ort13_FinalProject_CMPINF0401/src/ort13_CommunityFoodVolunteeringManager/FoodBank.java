package ort13_CommunityFoodVolunteeringManager;

public class FoodBank extends CommunityFoodOrg {

	private double maxCapacity;
	private double[] dailyDonationsNeeded= new double[7];
	
	String[] daysOfWeek= {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
	
	//Constructor
	public FoodBank(String id, String name, Location loc, TimeFrame[] dailyOH, double maxCap, double[] dailyDN, boolean offersT) {
		super(id,name,loc,dailyOH,offersT);
		maxCapacity=maxCap;
		dailyDonationsNeeded=dailyDN;
	}
	
	//Default setter for max capacity
	public void setMaxCapacity() {
		maxCapacity=500;
	}
	
	//Default setter for daily donations
	public void setDailyDonationsNeeded() {
		for(int i=0;i<7;i++) {
			dailyDonationsNeeded[i]=maxCapacity;
		}
	}
	
	//Getter for daily donations
	public double dailyDonationsNeeded(String dayName) {
		int k=0;
		for(int i=0;i<7;i++) {
			if(dayName.equals(daysOfWeek[i])) {
				k=i;
			}
		}return dailyDonationsNeeded[k];
	}
	
	//Setter for daily donations
	public void setDailyDonationsNeeded(double[] donations) {
		for(int i=0;i<7;i++) {
			if(donations[i]<0 || donations[i]>maxCapacity) {
				System.out.println("Invalid donation of " + String.valueOf(donations[i]));
			}else {
				dailyDonationsNeeded[i]=donations[i];
			}
		}
	}
	
	//Setter for daily donations
	public void setDailyDonationsNeeded(double donation, String dayName) {
		if(donation>0 && donation<maxCapacity) {
			for(int i=0;i<7;i++) {
				if(dayName.equals(daysOfWeek[i])) {
					dailyDonationsNeeded[i]=donation;
				}
			}
		}else {
			System.out.println("Invalid donation of " + String.valueOf(donation));
		}
	}
	
	//Setter for max capacity
	public void setMaxCapacity(double maxCap) {
		maxCapacity=maxCap;
	}
	
	/** Method signUpVolunteer
	 *  @param a Volunteer object
	 *	@return a boolean value as to whether the volunteer could be signed up
	 */
	
	@Override
	public boolean signUpVolunteer(Volunteer vol) {
		super.signUpVolunteer(vol);
		int k=0;
		for(int i=0;i<7;i++) {
			if(vol.getDayAvailable().equals(daysOfWeek[i])) {
				k=i;
				if(vol.getDonation()<dailyDonationsNeeded[k]) {
					dailyDonationsNeeded[k]-=vol.getDonation();
					return true;
				}
			}else {
				return false;
			}
		}return false;
		
	}

	/**
	 * Method cancelVolunteerSignup
	 * @param a a String dayName and b a double donation
	 * @return void
	 */
	
	public void cancelVolunteerSignUp(String dayName, double donation) {
		int k=0;
		for(int i=0;i<7;i++) {
			if(dayName.equals(daysOfWeek[i])) {
				k=i;
			}
		}
		dailyDonationsNeeded[k]+=donation;
	}
	

}
	

