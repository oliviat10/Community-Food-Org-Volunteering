package ort13_CommunityFoodVolunteeringManager;

public class FoodPantry extends CommunityFoodOrg {

	private int[] dailyVolunteersNeeded;
	private int[] dailyVolunteerSignups;
	
	String[] daysOfWeek= {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
	
	//Constructor
	public FoodPantry(String id, String name, Location loc, TimeFrame[] dailyOH, int[] dailyVN, int[] dailyVS, boolean offersT) {
		super(id,name,loc,dailyOH,offersT);
		dailyVolunteersNeeded=dailyVN;
		dailyVolunteerSignups=dailyVS;
	}
	
	//Setter for daily volunteers needed
	public void setDailyVolunteersNeeded(int[] volunteers) {
		dailyVolunteersNeeded=volunteers;
	}
	
	//Setter for daily volunteers needed
	public void setDailyVolunteersNeeded(int volunteers, String dayName) {
		int k=0;
		for(int i=0;i<7;i++) {
			if(dayName.equals(daysOfWeek[i])) {
				k=i;
			}
		}
		dailyVolunteersNeeded[k]=volunteers;
	}
	
	//Setter for daily volunteer signups
	public void setDailyVolunteerSignups(int signups, String dayName) {
		int k=0;
		for(int i=0;i<7;i++) {
			if(dayName.equals(daysOfWeek[i])) {
				k=i;
			}
		}
		dailyVolunteerSignups[k]=signups;
	}
	
	
	//Methods definition
		/**
		* Method signUpVolunteer
		* @param vol a Volunteer object
		* @return a boolean value:
		* 	true if vol could sign up on his/her available day to this org
		* 	false if not
		*/
		
		@Override
		public boolean signUpVolunteer(Volunteer vol) {
			super.signUpVolunteer(vol);
			int index = mapDayToIndex(vol.getDayAvailable());
			if(dailyVolunteerSignups[index]<dailyVolunteersNeeded[index]) {
				dailyVolunteerSignups[index] = dailyVolunteerSignups[index] + 1;
				return true;
			}
			return false;
		}
		
		
		/**
		* Method cancelVolunteerSignUp
		* @param dayName a String that represents the day we want to cancel a signup for the organization
		* @return nothing (it just cancels a signup associated to dayName day)
		*/
		
		@Override
		public void cancelVolunteerSignUp(String dayName) {
			super.cancelVolunteerSignUp(dayName);
			int index = mapDayToIndex(dayName);
			if((dailyVolunteerSignups[index]-1)>0) {
				dailyVolunteerSignups[index]--;
			}else {
				dailyVolunteerSignups[index]=0;
			}
		}
		
		/**
		 * Method dailyVolunteerSpotsLeft
		 * @param a String dayName
		 * @return an int value for the number of volunteer spots left on that day
		 */
		public int dailyVolunteerSpotsLeft(String dayName) {
			int k=0;
			for(int i=0;i<7;i++) {
				if(dayName.equals(daysOfWeek[i])) {
					k=i;
				}
			}
			return dailyVolunteersNeeded[k]-dailyVolunteerSignups[k];
		}
		

		
	}
