package ort13_CommunityFoodVolunteeringManager;
/**
 * Class Location
 * author: Olivia Terry
 * created: 05/01/2022
 */

public class Location {
	//Attributes declaration
	public double EARTH_RADIUS = 3958.8;
	private double latitude;
	private double longitude;
	private String address;
	private String city;
	private String state;
	private String zipCode;
	
	//Constructor declaration
	public Location(double lat, double lon, String addr, String city, String state, String zip) {
		this.latitude = lat;
		this.longitude = lon;
		this.address = addr;
		this.city = city;
		this.state = state;
		this.zipCode = zip;
	}
	
	//distance method
	//this method implements Harvesine distance
	public double distance(Location loc) {
		double lon2 = this.longitude;
		double lon1 = loc.getLongitude();
		double lat2 = this.latitude;
		double lat1 = this.getLatitude();
		double deltaLon =  lon2 - lon1;
		double deltaLat = lat2 - lat1;
		double a = Math.pow(Math.sin(deltaLat/2),2) + Math.cos(lat1)*Math.cos(lat2)*Math.pow(Math.sin(deltaLon/2),2);
		double c = 2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
		double r = EARTH_RADIUS*c;
		return r;
	}
	
	//Getters and setters
	
	//Getters
	public double getLatitude() {
		return latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public String getAddress() {
		return address;
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public String getZipCode() {
		return zipCode;
	}
	
	//Setters
	public void setLatitude(double newLat) {
		if (newLat<-90 || newLat>90) newLat = 0;
		this.latitude = newLat;
	}
	public void setLongitude(double newLon) {
		if (newLon<-180 || newLon>180) newLon = 0;
		this.longitude = newLon;
	}
	public void setAdress(String newAddr) {
		this.address = newAddr;
	}
	public void setCity(String newCity) {
		this.city = newCity;
	}
	public void setState(String newState) {
		this.state = newState;
	}
	public void setZipCode(String newZipCode) {
		this.zipCode = newZipCode;
	}
	
	//This is not needed, only for internal test of the objects of each
	//separate class
	public static void main(String[] args) {
		Location loc1 = new Location(40.419390,-79.928460,"828 Hazelwood Ave","Pittsburgh","PA","15217");
		Location loc2 = new Location(40.462820,-79.921700,"6140 Station Street","Pittsburgh","PA","15206");
		double dist = loc1.distance(loc2);
		System.out.println(dist);
	}
	
	
	
}
