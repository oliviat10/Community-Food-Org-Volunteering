package ort13_CommunityFoodVolunteeringManager;

/**
 * Class TimeFrame
 * author: Olivia Terry
 * created: 05/01/2022
 */

public class TimeFrame {
	
	//Attributes declaration
	private int hourStart;
	private int minuteStart;
	private int hourEnd;
	private int minuteEnd;
	
	//1st constructor definition
	public TimeFrame(int hs, int ms, int he, int me) {
		if(hs<0 || hs>23) hs=8;
		if(he<0 || he>23) he=8;
		if(ms<0 || ms>59) ms=0;
		if(me<0 || me>59) me=0;
		this.hourStart = hs;
		this.minuteStart = ms;
		this.hourEnd = he;
		this.minuteEnd = me;
	}
	
	//2nd constructor definition
	public TimeFrame(int hs, int he) {
		if(hs<0 || hs>23) hs=8;
		if(he<0 || he>23) he=8;
		this.hourStart = hs;
		this.minuteStart = 0;
		this.hourEnd = he;
		this.minuteEnd = 0;
	}
	
	//Setters and Getters
	
	//Getters
	public int getHourStart() {
		return hourStart;
	}
	public int getMinuteStart() {
		return minuteStart;
	}
	public int getHourEnd() {
		return hourEnd;
	}
	public int getMinuteEnd() {
		return minuteEnd;
	}
	
	//Setters
	public void setHourStart(int newHourStart) {
		if(newHourStart<0 || newHourStart>23) newHourStart = 8;
		this.hourStart = newHourStart; 
	}
	public void setHourEnd(int newHourEnd) {
		if(newHourEnd<0 || newHourEnd>23) newHourEnd = 8;
		this.hourEnd = newHourEnd; 
	}
	public void setMinuteStart(int newMinuteStart) {
		if(newMinuteStart<0 || newMinuteStart>59) newMinuteStart = 0;
		this.minuteStart = newMinuteStart;
	}
	public void setMinuteEnd(int newMinuteEnd) {
		if(newMinuteEnd<0 || newMinuteEnd>59) newMinuteEnd = 0;
		this.minuteEnd = newMinuteEnd;
	}
	
	//timeFrameMatch method
	public boolean timeFrameMatch(TimeFrame time) {
		boolean match = false;
		if (time.getHourStart()>=this.hourStart || (time.getHourStart()==this.hourStart && time.getMinuteStart()>=this.minuteStart)){
			if(time.getHourEnd()<=this.hourEnd || (time.getHourEnd()==this.hourEnd && time.getMinuteEnd()<=this.minuteEnd)){
				match = true;
			}
		}
		return match;
	}
	
	public static void main(String[] args) {
		TimeFrame time1 = new TimeFrame(13,17);
		TimeFrame time2 = new TimeFrame(12,0,17,0);
		boolean match = time1.timeFrameMatch(time2);
		System.out.println(match);
	}

}
