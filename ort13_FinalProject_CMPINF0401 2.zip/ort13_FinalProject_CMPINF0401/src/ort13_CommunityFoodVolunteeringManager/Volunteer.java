package ort13_CommunityFoodVolunteeringManager;

/**
 * Class Volunteer
 * author: Olivia Terry
 * created: 05/01/2022
 */

public class Volunteer {
	
	//Attributes declaration
	private String id;
	private String fullName;
	private int age;
	private Location location;
	private String dayAvailable;
	private TimeFrame timeAvailable;
	private double distanceAvailable;
	private boolean needsTransportation;
	private CommunityFoodOrg orgVolunteering;
	private double donation;
	
	//Constructor definition
	public Volunteer(String id, String name, int age, Location loc, String dayAv,TimeFrame timeAv,double distAv,boolean needTrans, double donation) {
		this.id = id;
		this.fullName = name;
		
		//Age constraint
		if(age<18 || age>100) age=18;
		this.age = age;
		
		this.location = loc;
		
		//Day constraint
		if(!dayAv.equals("Monday") && 
				!dayAv.equals("Tuesday") &&
				!dayAv.equals("Wednesday") &&
				!dayAv.equals("Thursday") &&
				!dayAv.equals("Friday") &&
				!dayAv.equals("Saturday") &&
				!dayAv.equals("Sunday")) {
			dayAv = "Monday";
		}
		this.dayAvailable = dayAv;
		this.timeAvailable = timeAv;
		this.distanceAvailable = distAv;
		this.needsTransportation = needTrans;
		this.orgVolunteering = null;
		this.donation=donation;
	}
	
	//Setters and Getters
	
	//Getters
	public String getId() {
		return id;
	}
	public String getFullName() {
		return fullName;
	}
	public int getAge() {
		return age;
	}
	public Location getLocation() {
		return location;
	}
	public String getDayAvailable() {
		return dayAvailable;
	}
	public double getDistanceAvailable() {
		return distanceAvailable;
	}
	public boolean getNeedsTransportation() {
		return needsTransportation;
	}
	public CommunityFoodOrg getOrgVolunteering() {
		return orgVolunteering;
	}
	public double getDonation() {
		return donation;
	}
	
	
	//Setters
	public void setId(String newId) {
		this.id = newId;
	}
	public void setFullName(String newFullName) {
		this.fullName = newFullName;
	}
	public void setAge(int newAge) {
		if(newAge<18 || newAge>100) newAge = 18;
		this.age = newAge;
	}
	public void setDayAvailable(String newDayAvailable) {
		if(!newDayAvailable.equals("Monday") && 
			!newDayAvailable.equals("Tuesday") &&
			!newDayAvailable.equals("Wednesday") &&
			!newDayAvailable.equals("Thursday") &&
			!newDayAvailable.equals("Friday") &&
			!newDayAvailable.equals("Saturday") &&
			!newDayAvailable.equals("Sunday")) {
			newDayAvailable = "Monday";
		}
		this.dayAvailable = newDayAvailable;
	}
	public void setTimeAvailable(TimeFrame newTimeAv) {
		this.timeAvailable = newTimeAv;
	}
	public void setDistanceAvailable(double newDistAv) {
		if(newDistAv<1) newDistAv=1;
		this.distanceAvailable = newDistAv;
	}
	public void setNeedsTransportation(boolean newNeedsTrans) {
		this.needsTransportation = newNeedsTrans;
	}
	public void setOrgVolunteering(CommunityFoodOrg newOrg) {
		this.orgVolunteering = newOrg;
	}
	public void setDonation(double donation) {
		if(donation<0) {
			System.out.println("Invalid donation of: " + String.valueOf(donation));
		}else {
			this.donation=donation;
		}
	}
	
	//Methods definition
	/**
	* Method signUp
	* @param org an object of type CommunityFoodOrg
	* @return nothing (it only signUp the volunteer to org, by calling the signUpVolunteer method from class CommunityFoodOrg)
	*/
	public void signUp(CommunityFoodOrg org) {
		boolean orgIsAvailable = org.signUpVolunteer(this);
		if(orgIsAvailable) {
			orgVolunteering = org;
		}
	}
	
	/**
	* Method cancelSignUp
	* @param nothing
	* @return nothing (in only cancels the signup of the current volunteer object from orgVolunteering)
	*/
	public void cancelSignup() {
		orgVolunteering.cancelVolunteerSignUp(this.dayAvailable);
		orgVolunteering = null;
	}
	
	/**
	* Method orgMatch
	* @param org an object of type CommunityFoodOrg
	* @return a boolean value:
	* 	true, if there is a match between the availability of org on receiving volunteers and the availability of the volunteer
	*	false, if there's no match (e.g. no day match, day match but no time match, no distance match, etc.)
	*/
	public boolean orgMatch(CommunityFoodOrg org) {
		int index = mapDayToIndex(dayAvailable);
		//Transportation constraint
		boolean transportationMatch = !needsTransportation || (needsTransportation && org.getOffersTransportation());
		
		//Time constraint
		boolean timeMatch = org.getDailyOpenHours()[index].timeFrameMatch(timeAvailable);
		
		boolean dayMatch=false;
		boolean donationMatch=false;
		if(donation>0) {
			if(org instanceof FoodBank) {
				if(donation>((FoodBank)org).dailyDonationsNeeded(dayAvailable)) {
					donationMatch=false;
				}else {
					donationMatch=true;
				}
			}
		}else {
			if(donation==0) {
				if(org instanceof FoodPantry) {
					donationMatch=true;
				}else {
					donationMatch=false;
				}
			}
		}
		
		//Final match assessment
		return (transportationMatch && dayMatch && timeMatch && donationMatch);
	}
	
	//Method that maps the string name to an index
	public int mapDayToIndex(String day) {
		int index = 0;
		if(day.equals("Monday")) {
			index=0;
		}else if(day.equals("Tuesday")){
			index=1;
		}else if(day.equals("Wednesday")) {
			index=2;
		}else if(day.equals("Thursday")) {
			index=3;
		}else if(day.equals("Friday")) {
			index=4;
		}else if(day.equals("Saturday")) {
			index=5;
		}else {
			index=6;
		}
		return index;
	}

}
