package ort13_CommunityFoodVolunteeringManager;
/**
 * Class VolunteeringManager
 * author: Olivia Terry
 * created: 05/01/2022
 */

import java.util.ArrayList;

public class VolunteeringManager {
	private ArrayList<CommunityFoodOrg> orgs;
	private ArrayList<Volunteer> volunteers;
	
	public VolunteeringManager(String orgsFileName, String volunteersFileName) {
		orgs = DataManager.readCommunityFoodOrgs(orgsFileName);
		volunteers = DataManager.readVolunteers(volunteersFileName);
	}
	
	public ArrayList<Volunteer> getVolunteers(){
		return volunteers;
	}
	
	public ArrayList<CommunityFoodOrg> getOrgs(){
		return orgs;
	}
	
	/**
	* Method signUpVolunteerToPriorityOrg
	* @param volunteer an object Volunteer
	* @return the result on attempting to signing up volunteer to the organization which:
	* 	(1) matches in terms of day and time of availability
	* 	(2) has the maximum number of spots left to be filled with volunteers
	* true if it could sign up to an organization, false if not
	*/	
	public boolean signUpVolunteerToPriorityOrg(Volunteer volunteer) {
		boolean signedUp = true;
		if(orgs.size()>0) {
			//We set the first value for max spots left as the maximum
			int maxSpotsLeft = ((FoodPantry)orgs.get(0)).dailyVolunteerSpotsLeft(volunteer.getDayAvailable());
			int maxIndex = 0;
				
			//Then we need to start checking the values starting from the second element (not the first)
			for(int i=1;i<orgs.size();i++) {
				int spotsLeft = ((FoodPantry)orgs.get(i)).dailyVolunteerSpotsLeft(volunteer.getDayAvailable());
				if(spotsLeft>maxSpotsLeft) {
					maxSpotsLeft = spotsLeft;
					maxIndex = i;
				}
			}
			
			//Signup the volunteer with the priority org (the one in the position maxIndex within the arraylist orgs)
			volunteer.signUp(orgs.get(maxIndex));
			if(volunteer.getOrgVolunteering()==null) {
				signedUp = false;
			}
		
		}else {
			signedUp = false;
		}
		return signedUp;
	}
	
	//Method that maps the string name to an index
	public int mapDayToIndex(String day) {
		int index = 0;
		if(day.equals("Monday")) {
			index=0;
		}else if(day.equals("Tuesday")){
			index=1;
		}else if(day.equals("Wednesday")) {
			index=2;
		}else if(day.equals("Thursday")) {
			index=3;
		}else if(day.equals("Friday")) {
			index=4;
		}else if(day.equals("Saturday")) {
			index=5;
		}else {
			index=6;
		}
		return index;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
