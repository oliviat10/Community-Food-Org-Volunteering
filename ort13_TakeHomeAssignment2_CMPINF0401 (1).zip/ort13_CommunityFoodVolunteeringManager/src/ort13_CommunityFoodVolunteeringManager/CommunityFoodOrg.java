package ort13_CommunityFoodVolunteeringManager;
/**
 *Class: CommunityFoodOrg
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class CommunityFoodOrg {
	//Declaration of attributes
	private int[] dailyVolunteersNeeded;
	private int[] dailyVolunteerSignups;
	private TimeFrame[] dailyOpenHours;
	private Location location;
	private String id;
	private String name;
	private boolean offersTransportation;
	private String[] weekDays= {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
	private TimeFrame[] nullArray= {null, null, null, null, null, null, null};
	private int[] zeroArray= {0,0,0,0,0,0,0};

	//Constructor definitions
	public CommunityFoodOrg(String id, String name, Location loc, TimeFrame[] dailyOH, int[] dailyVN, int[] dailyVS, boolean offersT) {
		this.id=id;
		this.name=name;
		location=loc;
		//Check validity of parameters
		for(int i=0;i<7;i++) {
			if(dailyVN[i]>=0 && dailyVN.length==7) {
				dailyVolunteersNeeded=dailyVN.clone();
			}else {
				dailyVolunteersNeeded=zeroArray.clone();
			}
			if(dailyVS[i]>=0 && dailyVN.length==7) {
				dailyVolunteerSignups=dailyVS.clone();
			}else {
				dailyVolunteerSignups=zeroArray.clone();
			}
			if(dailyOH.length>7) {
				dailyOpenHours= nullArray.clone();
			}else {
				dailyOpenHours=dailyOH.clone();
			}
		}
		offersTransportation=offersT;
	}

	//Setter for organization's ID
	public void setID(String id) {
		this.id=id;
	}
	//Getter for organization's ID
	public String getID() {
		return id;
	}
	//Setter for organization's name
	public void setName(String name) {
		this.name=name;
	}
	//Getter for organization's name
	public String getName() {
		return name;
	}
	//Setter for organization's location
	public void setLocation(Location loc) {
		location=loc;
	}
	//Getter for organization's location
	public Location getLocation() {
		return location;
	}
	//Setter for number of daily volunteers needed
	public void setDailyVolunteersNeeded(int volunteers, String dayName) {
		if(volunteers==0) {
			System.out.println("The community food organization is closed (no volunteers needed)");
		}else {
			if(dayName.equals("Monday")) {
				dailyVolunteersNeeded[0]=volunteers;
			}else if(dayName.equals("Tuesday")) {
				dailyVolunteersNeeded[1]=volunteers;
			}else if(dayName.equals("Wednesday")) {
				dailyVolunteersNeeded[2]=volunteers;
			}else if(dayName.equals("Thursday")) {
				dailyVolunteersNeeded[3]=volunteers;
			}else if(dayName.equals("Friday")) {
				dailyVolunteersNeeded[4]=volunteers;
			}else if(dayName.equals("Saturday")) {
				dailyVolunteersNeeded[5]=volunteers;
			}else if(dayName.equals("Sunday")) {
				dailyVolunteersNeeded[6]=volunteers;
			}
		}
	}
	//Overload setter for number of daily volunteers needed
	public void setDailyVolunteersNeeded(int[] volunteers) {
		dailyVolunteersNeeded=volunteers.clone();
	}
	//Getter for number of daily volunteers needed
	public int getDailyVolunteersNeeded(String dayName) {
		for(int i=0;i<7;i++) {
			if(dayName.equalsIgnoreCase(weekDays[i])) {
				return dailyVolunteersNeeded[i];
			}
		}return dailyVolunteersNeeded[0];
	}
	//Setter for number of daily volunteer signups
	public void setDailyVolunteerSignups(int signups, String dayName) {
		if (signups==0) {
			System.out.println("The community food organization does not have any signups on this day");
		}else {
			if(dayName.equals("Monday")) {
				dailyVolunteerSignups[0]=signups;
			}else if(dayName.equals("Tuesday")) {
				dailyVolunteerSignups[1]=signups;
			}else if(dayName.equals("Wednesday")) {
				dailyVolunteerSignups[2]=signups;
			}else if(dayName.equals("Thursday")) {
				dailyVolunteerSignups[3]=signups;
			}else if(dayName.equals("Friday")) {
				dailyVolunteerSignups[4]=signups;
			}else if(dayName.equals("Saturday")) {
				dailyVolunteerSignups[5]=signups;
			}else if(dayName.equals("Sunday")) {
				dailyVolunteerSignups[6]=signups;
			}
		}
	}
	//Overload setter for number of daily volunteer signups
	public void setDailyVolunteerSignups(int[] signups) {
		dailyVolunteerSignups=signups.clone();
	}
	//Getter for number of daily volunteer signups
	public int getDailyVolunteerSignups(String dayName) {
		for(int i=0;i<7;i++) {
			if(dayName.equals(weekDays[i])) {
				return dailyVolunteerSignups[i];
			}
		}return dailyVolunteerSignups[0];
	}
	//Setter for daily open hours based on day of week
	public void setDailyOpenHours(TimeFrame[] time, String dayName) {
		if(dayName.equals("Monday")) {
			dailyOpenHours[0]=time[0];
		}else if(dayName.equals("Tuesday")) {
			dailyOpenHours[1]=time[1];
		}else if(dayName.equals("Wednesday")) {
			dailyOpenHours[2]=time[2];
		}else if(dayName.equals("Thursday")) {
			dailyOpenHours[3]=time[3];
		}else if(dayName.equals("Friday")) {
			dailyOpenHours[4]=time[4];
		}else if(dayName.equals("Saturday")) {
			dailyOpenHours[5]=time[5];
		}else if(dayName.equals("Sunday")) {
			dailyOpenHours[6]=time[6];
		}
		if(dailyOpenHours==null) {
			System.out.println("The community food organization is not accepting volunteers on " + dayName);
		}
	}
	//Overload setter for daily open hours
	public void setDailyOpenHours(TimeFrame[] times) {
		String dayOfWeek;
		for(int i=0;i<7;i++) {
			if(times[i]==null) {
				dayOfWeek= weekDays[i];
				System.out.println("The community food organization is not accepting volunteers on " + dayOfWeek);
			}
		}
		dailyOpenHours=times.clone();
	}
	//Getter for daily open hours
	public TimeFrame[] getDailyOpenHours() {
		return dailyOpenHours;
	}
	//Setter for whether or not organization offers transportation to its volunteers
	public void setOffersTransportation(boolean offersT) {
		offersTransportation=offersT;
	}
	//Getter for whether or not organization offers transportation to its volunteers
	public boolean getOffersTransportation() {
		return offersTransportation;
	}
	/**
	 * Method dailyVolunteerSpotsLeft
	 * @param a a String dayName (to specify day of the week in which to find remaining availability)
	 * @return an int value of the number of remaining volunteer spots for a certain org on a certain day
	 */
	public int dailyVolunteerSpotsLeft(String dayName) {
		return (getDailyVolunteersNeeded(dayName)-getDailyVolunteerSignups(dayName));
	}

	/**
	 * Method signUpVolunteer
	 * @param a a volunteer object (to specify the data from a certain person)
	 * @return a boolean value (truth value to ensure number of vol. signups has not exceeded number of vols. needed)
	 */
	public boolean signUpVolunteer(Volunteer volunteer) {
		int k=0;
		for(int i=0;i<7;i++) {
			if(weekDays[i].equals(volunteer.getDayAvailable())) {
				k=i;
			}
		}
		//Ensure availability and that number of sign ups does not exceed volunteer requirement
		if (dailyVolunteerSpotsLeft(volunteer.getDayAvailable())>0){
			dailyVolunteerSignups[k]++;
			if (dailyVolunteerSignups[k]>dailyVolunteersNeeded[k]) {
				dailyVolunteerSignups[k]=dailyVolunteersNeeded[k];
			}
			return true;
		}else {
			return false;
		}
	}
	/**
	 * Method cancelVolunteerSignup
	 * @param a String dayName (to specify which day of the week is having its volunteer count adjusted)
	 */
	public void cancelVolunteerSignup(String dayName) { 
		int j=0;
		for(int i=0;i<7;i++) {
			if(dayName.equals(weekDays[i])) {
				j=i;
			}
		}
		//Ensure there is a volunteer already signed up who can be removed
		if (dailyVolunteerSignups[j]>0) {
			dailyVolunteerSignups[j]--;
		}else {
			System.out.println("No volunteer has signed up yet");
		}
	}
}


