package ort13_CommunityFoodVolunteeringManager;
import java.util.ArrayList;
/**
 *Class: CommunityFoodVolunteeringTester
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class CommunityFoodVolunteeringTester {

	//Method that maps the day index to the string name
	public static String mapIndexToDay(int index) {
		String day = "";
		if(index==0) {
			day="Monday";
		}else if(index==1){
			day="Tuesday";
		}else if(index==2) {
			day="Wednesday";
		}else if(index==3) {
			day="Thursday";
		}else if(index==4) {
			day="Friday";
		}else if(index==5) {
			day="Saturday";
		}else {
			day="Sunday";
		}
		return day;
	}

	//Main method for creation of objects and testing
	public static void main(String[] args) {
		VolunteeringManager volManager= new VolunteeringManager("data/community_food_organizations.txt","data/volunteers.txt");
		ArrayList<Volunteer> volunteers= volManager.getVolunteers();
		ArrayList<CommunityFoodOrg> orgs= volManager.getOrgs();
		
		//Check how many spots left per day per organization, per day, after the signups plus the individual cancellation
		for(int j=0;j<orgs.size();j++) {
			System.out.println("");
			CommunityFoodOrg org = orgs.get(j);
			System.out.println(org.getName());
			for(int k=0;k<7;k++) {
				System.out.println(mapIndexToDay(k)+" - Volunteer spots left: "+org.dailyVolunteerSpotsLeft(mapIndexToDay(k)));
			}
		}

		//Assign each of the volunteers read from the volunteers.txt file to the most-priority organization at the moment
		for(int i=0;i<volunteers.size();i++) {
			volManager.signUpVolunteerToPriorityOrg(volunteers.get(i));
		}

		for(int i=0;i<10;i++) {
			for(int f=0;f<10;f++)
				if(volunteers.get(i).orgMatch(orgs.get(f))) {
					Volunteer volunteer = volunteers.get(i);
					CommunityFoodOrg org= orgs.get(f);
					volunteer.signUp(org,volunteer);
				}
		}
		
		
		//We cancel the signup from the first volunteer
		volunteers.get(0).cancelSignup();

		//Check how many spots left per day per organization, per day, after the signups plus the individual cancellation
		for(int j=0;j<orgs.size();j++) {
			System.out.println("");
			CommunityFoodOrg org = orgs.get(j);
			System.out.println(org.getName());
			for(int k=0;k<7;k++) {
				System.out.println(mapIndexToDay(k)+" - Volunteer spots left: "+org.dailyVolunteerSpotsLeft(mapIndexToDay(k)));
			}
		}
		
		
			//Check for compatibility between volunteers and community food organizations
			//First volunteer test
			if(volunteers.get(0).orgMatch(orgs.get(7))) {
				System.out.println("\n\nIt's a match!");
				if(orgs.get(7).signUpVolunteer(volunteers.get(0))) {
					System.out.println(volunteers.get(0).getFullName() + " was signed up to " + orgs.get(7).getName() + " successfully!\n\n");
				}
			}else{
				System.out.println(volunteers.get(0).getFullName() + " is not a match for " + orgs.get(7).getName() + "\n\n");
			}
			
			//Second volunteer test
			if(volunteers.get(1).orgMatch(orgs.get(9))){
				System.out.println("It's a match!");
				if(orgs.get(9).signUpVolunteer(volunteers.get(1))) {
					System.out.println(volunteers.get(1).getFullName() + " was signed up to " + orgs.get(9).getName() + " successfully!\n\n");
				}
			}else{
				System.out.println(volunteers.get(1).getFullName() + " is not a match for " + orgs.get(9).getName() + "\n\n");
			}
			
			//Third volunteer test
			if(volunteers.get(4).orgMatch(orgs.get(3))){
				System.out.println("It's a match!");
				if(orgs.get(3).signUpVolunteer(volunteers.get(4))) {
					System.out.println(volunteers.get(4).getFullName() + " was signed up to " + orgs.get(3).getName() + " successfully!\n\n");
				}
			}else {
				System.out.println(volunteers.get(4).getFullName() + " is not a match for " + orgs.get(3).getName() + "\n\n");
			}
			
			//Fourth volunteer test
			if(volunteers.get(5).orgMatch(orgs.get(1))){
				System.out.println("It's a match!");
				if(orgs.get(1).signUpVolunteer(volunteers.get(5))) {
					System.out.println(volunteers.get(5).getFullName() + " was signed up to " + orgs.get(1).getName() + " successfully!\n\n");
				}
			}else {
				System.out.println(volunteers.get(5).getFullName() + " is not a match for " + orgs.get(1).getName() + "\n\n");
			}
			
			//Fifth volunteer test
			if(volunteers.get(6).orgMatch(orgs.get(6))){
				System.out.println("It's a match!");
				if(orgs.get(6).signUpVolunteer(volunteers.get(6))) {
					System.out.println(volunteers.get(6).getFullName() + " was signed up to " + orgs.get(6).getName() + " successfully!\n\n");
				}
			}else {
				System.out.println(volunteers.get(5).getFullName() + " is not a match for " + orgs.get(1).getName() + "\n\n");
			}
			
			//Sixth volunteer test
			if(volunteers.get(7).orgMatch(orgs.get(2))){
				System.out.println("It's a match!");
				if(orgs.get(2).signUpVolunteer(volunteers.get(7))) {
					System.out.println(volunteers.get(7).getFullName() + " was signed up to " + orgs.get(2).getName() + " successfully!\n\n");
				}
			}else {
				System.out.println(volunteers.get(7).getFullName() + " is not a match for " + orgs.get(2).getName() + "\n\n");
			}
			
			//Seventh volunteer test
			if(volunteers.get(8).orgMatch(orgs.get(4))){
				System.out.println("It's a match!");
				if(orgs.get(4).signUpVolunteer(volunteers.get(8))) {
					System.out.println(volunteers.get(8).getFullName() + " was signed up to " + orgs.get(4).getName() + " successfully!\n\n");
				}
			}else {
				System.out.println(volunteers.get(8).getFullName() + " is not a match for " + orgs.get(4).getName() + "\n\n");
			}
			
			//Eighth volunteer test
			if(volunteers.get(9).orgMatch(orgs.get(5))){
				System.out.println("It's a match!");
				if(orgs.get(5).signUpVolunteer(volunteers.get(9))) {
					System.out.println(volunteers.get(9).getFullName() + " was signed up to " + orgs.get(5).getName() + " successfully!\n\n");
				}
			}else {
				System.out.println(volunteers.get(9).getFullName() + " is not a match for " + orgs.get(5).getName() + "\n\n");
			}
			
	}

}