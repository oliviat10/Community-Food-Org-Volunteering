package ort13_CommunityFoodVolunteeringManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;
/**
 *Class: DataManager
 *Author: Olivia Terry
 *Created: 4/13/2022
 */

public class DataManager {

	/**
	 * Method readVolunteers
	 * @param a a String fileName (name of the text file containing the volunteer data)
	 * @return an ArrayList<Volunteer> (an ArrayList of the information specific to a certain volunteer)
	 */
	public static ArrayList<Volunteer> readVolunteers(String fileName){
		ArrayList<Volunteer> volArray= new ArrayList<Volunteer>();
		try {
			//Create a new FileReader and BufferedReader to read lines from text files
			FileReader fr=new FileReader(fileName);
			BufferedReader br=new BufferedReader(fr);
			//New String variable to hold lines of text
			String line=null;
			//New boolean value to evaluate whether or not the volunteer needs transportation
			boolean bool=false;
			//New int values to hold the hour and minute values for the volunteer's time availability
			int startTimeHour;
			int startTimeMinute;
			int endTimeHour;
			int endTimeMinute;
			//Read through all the lines in the text file containing volunteer data
			while((line=br.readLine()) != null) {
				//Split the current line by semi-colons into a new String array
				String[] arrLine= line.split(";");
				//Set volunteer's full name
				String volName= arrLine[2]+ " " + arrLine[1];
				//Obtain values for the volunteer's time availability 
				startTimeHour=Integer.valueOf(arrLine[11].split(":")[0]);
				startTimeMinute=Integer.valueOf(arrLine[11].split(":")[1]);
				endTimeHour=Integer.valueOf(arrLine[12].split(":")[0]);
				endTimeMinute=Integer.valueOf(arrLine[12].split(":")[1]);
				//Obtain the volunteer's location using their latitude, longitude, and address
				Location loc= new Location(Double.valueOf(arrLine[4]),Double.valueOf(arrLine[5]),arrLine[6],arrLine[7],arrLine[8],arrLine[9]);
				//Obtain volunteer's time availability by creating a new TimeFrame object with the found int values
				TimeFrame tf= new TimeFrame(startTimeHour,startTimeMinute,endTimeHour,endTimeMinute);

				//Find whether the volunteer needs transportation
				if((arrLine[14]).equals("yes")) {
					bool=true;
				}

				//Create a new volunteer using the acquired information above
				Volunteer vol= new Volunteer(arrLine[0],volName,Integer.valueOf(arrLine[3]),loc,arrLine[10],tf,Double.valueOf(arrLine[13]), bool);
				
				//Add the new volunteer to the ArrayList of volunteer
				volArray.add(vol);
			}
			//Close the BufferedReader and FileReader
			br.close();
			fr.close();
			//Catch IOExceptions and locate errors (used during code-testing)
		}catch(IOException e){
			e.printStackTrace();
			System.out.println("The text file is empty!");
		}
		//Return the ArrayList of volunteers
		return volArray;
	}

	/**
	 * Method readCommunityFoodOrgs
	 * @param a a String fileName (name of the text file containing the community food organizations data)
	 * @return an ArrayList<CommunityFoodOrg> (an ArrayList of the information specific to a certain community food organization)
	 */
	public static ArrayList<CommunityFoodOrg> readCommunityFoodOrgs(String fileName){
		ArrayList<CommunityFoodOrg> foodOrgArray= new ArrayList<CommunityFoodOrg>();
		String[] weekDays= {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
		try {
			FileReader fr=new FileReader(fileName);
			BufferedReader br=new BufferedReader(fr);
			String line2=null;
			TimeFrame[] tf2= new TimeFrame[7];
			int[] volsNeed= new int[7];
			int[] volsSigns= new int[7];
			boolean bool2=false;

			while((line2=br.readLine()) != null) {
				String[] arrLine2=line2.split("[;:@]");
				System.out.println(Arrays.toString(arrLine2));
				int startTimeHour;
				int startTimeMinute;
				int endTimeHour;
				int endTimeMinute;
				String[] organizeTimes= line2.split("[;@]");
				int lenTimes=organizeTimes.length;
				for(int i=0;9+4*i<lenTimes;i++) {
					for(int j=0;j<7;j++) {
						if(arrLine2[9+4*i].equals(weekDays[j])) {
							startTimeHour=Integer.valueOf((organizeTimes[10+4*i].split(":"))[0]);
							startTimeMinute=Integer.valueOf((organizeTimes[10+4*i].split(":"))[1]);
							endTimeHour=Integer.valueOf((organizeTimes[11+4*i].split(":"))[0]);
							endTimeMinute=Integer.valueOf((organizeTimes[11+4*i].split(":"))[1]);
							TimeFrame timeOpen= new TimeFrame(startTimeHour,startTimeMinute,endTimeHour,endTimeMinute);
							tf2[j]=timeOpen;
							for(int p=12;p<lenTimes;p+=4) {
								for(int f=0;f<7;f++) {
									volsNeed[j]=Integer.valueOf(organizeTimes[p]);
								}
							}if(organizeTimes[8].equals("yes")) {
								bool2=true;
							}
						}
					}
				}

					Location loc2= new Location(Double.valueOf(arrLine2[2]),Double.valueOf(arrLine2[3]),arrLine2[4],arrLine2[5],arrLine2[6],arrLine2[7]);

					
					CommunityFoodOrg foodOrg= new CommunityFoodOrg(arrLine2[0],arrLine2[1],loc2,tf2,volsNeed,volsSigns,bool2);
					
					//Add new CommunityFoodOrg object to the ArrayList of food orgs
					foodOrgArray.add(foodOrg);
			}
			br.close();
			fr.close();
			
			
		}catch(IOException e){
			e.printStackTrace();
			System.out.println("The text file is empty!!!");
		}
		//Return the ArrayList of community food organizations
		return foodOrgArray;

	}
	
	
}