package ort13_CommunityFoodVolunteeringManager;

/**
 *Class: TimeFrame
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class TimeFrame {
	//Attribute declarations
	public int hourStart;
	public int minuteStart;
	public int hourEnd;
	public int minuteEnd;

	//First constructor (hour values only)
	public TimeFrame(int hourStart, int hourEnd){
		this.hourStart=hourStart;
		this.hourEnd=hourEnd;
		minuteStart=0;
		minuteEnd=0;
	}

	//Second constructor (minute-inclusive)
	public TimeFrame(int hourStart, int minuteStart, int hourEnd, int minuteEnd) {
		this.hourStart=hourStart;
		this.minuteStart=minuteStart;
		this.hourEnd=hourEnd;
		this.minuteEnd=minuteEnd;
	}

	//Setter for starting hour of the time frame
	public void setHourStart(int hourStart) {
		//Ensure the starting hour is a feasible value (if not, default to 8)
		if (hourStart<0 || hourStart>23) {
			hourStart=8;
		}
		this.hourStart=hourStart;
	}
	//Getter for starting hour
	public int getHourStart() {
		return hourStart;
	}

	//Setter for ending hour of the time frame
	public void setHourEnd(int hourEnd) {
		//Ensure the ending hour is a feasible value (if not, default to 8)
		if (hourEnd<0 || hourEnd>23) {
			hourEnd=8;
		}
		this.hourEnd=hourEnd;
	}
	//Getter for ending hour
	public int getHourEnd() {
		return hourEnd;
	}

	//Setter for starting minutes of time frame
	public void setMinuteStart(int minuteStart) {
		//Ensure the starting minute value is feasible (if not, default to 0)
		if (minuteStart<0 || minuteStart>59) {
			minuteStart=0;
		}
		this.minuteStart=minuteStart;
	}
	//Getter for starting minutes
	public int getMinuteStart() {
		return minuteStart;
	}

	//Setter for ending minutes of time frame
	public void setMinuteEnd(int minuteEnd) {
		//Ensure the ending minute value is feasible (if not, default to 0)
		if (minuteEnd<0 || minuteEnd>59) {
			minuteEnd=0;
		}
		this.minuteEnd=minuteEnd;
	}
	//Getter for ending minutes
	public int getMinuteEnd() {
		return minuteEnd;
	}

	/**
	 * Method timeFrameMatch
	 * @param a a TimeFrame object (to compare the organization's open time frame to that of the volunteer)
	 * @return a boolean value as to whether or not the time frames are compatible
	 */
	public boolean timeFrameMatch(TimeFrame time){
		int timeFrame1_hourStart=getHourStart();
		int timeFrame1_hourEnd=getHourEnd();
		int timeFrame1_minuteStart=getMinuteStart();
		int timeFrame1_minuteEnd=getMinuteEnd();

		int timeFrame2_hourStart=time.getHourStart();
		int timeFrame2_hourEnd=time.getHourEnd();
		int timeFrame2_minuteStart=time.getMinuteStart();
		int timeFrame2_minuteEnd=time.getMinuteEnd();

		
		
		if((timeFrame1_hourEnd<timeFrame2_hourEnd)&&(timeFrame1_hourStart>timeFrame2_hourStart)){
			return true;
		}else if((timeFrame1_hourEnd==timeFrame2_hourEnd)&&(timeFrame1_hourStart==timeFrame2_hourStart)&&(timeFrame1_minuteEnd<=timeFrame2_minuteEnd) && (timeFrame1_minuteStart>=timeFrame2_minuteStart)){
			return true;
		}else if((timeFrame1_hourEnd==timeFrame2_hourEnd)&&(timeFrame1_hourStart>timeFrame2_hourStart)&&(timeFrame1_minuteEnd<=timeFrame2_minuteEnd) && (timeFrame1_minuteStart>=timeFrame2_minuteStart)){
			return true;
		}else if((timeFrame1_hourEnd<timeFrame2_hourEnd)&&(timeFrame1_hourStart==timeFrame2_hourStart)&&(timeFrame1_minuteEnd<=timeFrame2_minuteEnd) && (timeFrame1_minuteStart>=timeFrame2_minuteStart)) {
			return true;
		}return false;
	}
}

