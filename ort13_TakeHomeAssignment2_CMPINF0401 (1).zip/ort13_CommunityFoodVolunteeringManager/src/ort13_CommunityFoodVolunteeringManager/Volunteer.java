package ort13_CommunityFoodVolunteeringManager;

/**
 *Class: Volunteer
 *Author: Olivia Terry
 *Created: 2/24/2022
 */

public class Volunteer {
	//Attribute declaration
	private String id;
	private String fullName;
	private int age;
	private Location location;
	private String dayAvailable;
	private TimeFrame timeAvailable;
	private double distanceAvailable;
	private boolean needsTransportation;
	private CommunityFoodOrg orgVolunteering;
	private String[] weekDays= {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};

	//Constructor definition
	public Volunteer(String id, String name, int age, Location loc, String dayAv, TimeFrame timeAv, double distAv, boolean needTrans) {
		this.id=id;
		fullName=name;
		this.age=age;
		location=loc;
		if(dayAv.equals("Monday") || dayAv.equals("Tuesday") || dayAv.equals("Wednesday") || dayAv.equals("Thursday") || dayAv.equals("Friday") || dayAv.equals("Saturday") || dayAv.equals("Sunday")) {
			dayAvailable=dayAv;
		}else {//If not, default to Monday
			dayAvailable="Monday";
		}
		timeAvailable=timeAv;
		distanceAvailable=distAv;
		needsTransportation=needTrans;
	}

	//Setter for volunteer ID
	public void setID(String id) {
		this.id=id;
	}
	//Getter for volunteer ID
	public String getID() {
		return id;
	}
	//Setter for volunteer's full name
	public void setFullName(String name) {
		fullName=name;
	}
	//Getter for volunteer's full name
	public String getFullName() {
		return fullName;
	}
	//Setter for volunteer's age
	public void setAge(int age) {
		//Ensure volunteer is within the age requirement (if not, assume/default to 18)
		if (age<18 || age>100) {
			age=18;
		}
		this.age=age;
	}
	//Getter for volunteer's age
	public int getAge() {
		return age;
	}
	//Setter for volunteer organization
	public void setOrganization(CommunityFoodOrg org) {
		orgVolunteering=org;
	}
	//Getter for volunteer organization
	public CommunityFoodOrg getOrganization() {
		return orgVolunteering;
	}
	//Setter for volunteer's day of availability
	public void setDayAvailable(String dayAv) {
		dayAvailable=dayAv;
	}
	//Getter for volunteer's day of availability
	public String getDayAvailable() {
		return dayAvailable;
	}
	//Setter for volunteer's available time frame
	public void setTimeAvailability(TimeFrame timeAv) {
		//Ensure validity of hour and minute start and end times
		if (timeAv.hourStart<0 || timeAv.hourStart>23){
			timeAvailable.hourStart=8;
		}if (timeAv.hourEnd<0 || timeAv.hourEnd>23) {
			timeAvailable.hourEnd=8;
		}if (timeAv.minuteStart<0 || timeAv.minuteStart>59) {
			timeAvailable.minuteStart=0;
		}if (timeAv.minuteEnd<0 || timeAv.minuteEnd>59) {
			timeAvailable.minuteEnd=0;
		}else {
			timeAvailable=timeAv;
		}
	}
	//Getter for volunteer's available time frame
	public TimeFrame getTimeAvailability() {
		return timeAvailable;
	}
	//Setter for volunteer's available distance
	public void setDistanceAvailable(double distanceAv) {
		distanceAvailable=distanceAv;
	}
	//Getter for volunteer's available distance
	public double getDistanceAvailable() {
		return distanceAvailable;
	}
	//Setter for whether or not volunteer needs transportation
	public void setNeedsTransportation(boolean needTrans) {
		needsTransportation=needTrans;
	}
	//Getter for whether or not volunteer needs transportation
	public boolean getNeedsTransportation() {
		return needsTransportation;
	}
	/**
	 * Method signUp
	 * @param a CommunityFoodOrg object org (to specify which organization to sign a volunteer up for)
	 */
	public void signUp(CommunityFoodOrg org, Volunteer vol) {
		//Adds a volunteer to the organization's sign up count
		if (org.signUpVolunteer(vol)) {
			orgVolunteering=org;
		}
	}
	/**
	 * Method cancelSignup
	 * @param a a String dayName (to specify day of the week in which to decrease signup count)
	 */
	public void cancelSignup() {
		//Removes a volunteer from the organization's sign up count
		orgVolunteering=null;
	}
	/**
	 * Method orgMatch
	 * @param a CommunityFoodOrg object org (in order to specify an organization and use the methods of respective class)
	 * @return a boolean value (to evaluate whether or not the organization is a match for the volunteer)
	 */
	public boolean orgMatch(CommunityFoodOrg org) {

		//Transportation constraint
		boolean transportationMatch= ((this.getNeedsTransportation()==false)||(org.getOffersTransportation()==true));
		if((this.getNeedsTransportation()==false) && !(org.getOffersTransportation())) {
			transportationMatch=true;
		}
		//System.out.println("transportation match? " + transportationMatch);

		//Location constraint
		Location orgLocation=org.getLocation();
		boolean distanceMatch= this.getDistanceAvailable()<=(orgLocation.distance(location));
		//System.out.println("distance match? " + distanceMatch);

		//Daily open hours constraint
		TimeFrame volAvailability = this.getTimeAvailability();
		TimeFrame[] orgTimeFrameArrayList= org.getDailyOpenHours();
		boolean openHoursMatch=false;
		try {
			for(int i=0;i<7;i++) {
				if(this.getDayAvailable().equals(weekDays[i])) {
					if(orgTimeFrameArrayList[i]!=null){
						TimeFrame orgAvailability=orgTimeFrameArrayList[i];
						openHoursMatch= volAvailability.timeFrameMatch(orgAvailability);
						
					}
				}
			}
			boolean volunteerMatch= (transportationMatch && distanceMatch && openHoursMatch);
			return volunteerMatch;
			
		}catch(NullPointerException e) {
			System.out.println("The organization is not open on this day");
			openHoursMatch=false;
			boolean volunteerMatch= (transportationMatch && distanceMatch && openHoursMatch);
			return volunteerMatch;
		}
		//System.out.println("hours match? " + openHoursMatch);
		//Final match assessment
		
		//System.out.println("volunteer match? " + volunteerMatch);
	}
}






