package ort13_CommunityFoodVolunteeringManager;
import java.util.ArrayList;
/**
 *Class: VolunteeringManager
 *Author: Olivia Terry
 *Created: 4/13/2022
 */

public class VolunteeringManager {
	private ArrayList<CommunityFoodOrg> orgs;
	private ArrayList<Volunteer> volunteers;

	//Constructor, uses DataManager methods to load data from text files
	public VolunteeringManager(String orgsFileName, String volunteersFileName) {
		orgs=DataManager.readCommunityFoodOrgs(orgsFileName);
		volunteers=DataManager.readVolunteers(volunteersFileName);
	}

	//Setter for orgs ArrayList
	public void setOrgs(ArrayList<CommunityFoodOrg> orgs) {
		this.orgs=orgs;
	}
	//Getter for orgs ArrayList
	public ArrayList<CommunityFoodOrg> getOrgs(){
		return orgs;
	}
	//Setter for volunteers ArrayList
	public void setVolunteers(ArrayList<Volunteer> volunteers) {
		this.volunteers=volunteers;
	}
	//Getter for volunteers ArrayList
	public ArrayList<Volunteer> getVolunteers(){
		return volunteers;
	}


	/**
	 * Method signUpVolunteerToPriorityOrg
	 * @param a a volunteer object (specific person from the volunteers file)
	 * @return a boolean value (true or false depending on whether or not volunteer was successfully signed up)
	 */
	public boolean signUpVolunteerToPriorityOrg(Volunteer volunteer) {
		int highestNeed=0;
		int highestNeedIndex=0;
		for(int i=0;i<orgs.size();i++) {
			if(orgs.get(i).dailyVolunteerSpotsLeft(volunteer.getDayAvailable())>highestNeed) {
				highestNeed=orgs.get(i).dailyVolunteerSpotsLeft(volunteer.getDayAvailable());
				highestNeedIndex=i;
			}
		}
		volunteer.signUp(orgs.get(highestNeedIndex),volunteer);
		//Check to see if volunteer was successfully signed up
		if(orgs.get(highestNeedIndex).signUpVolunteer(volunteer)) {
			return true;
		}else {
			return false;
		}
	}

}
